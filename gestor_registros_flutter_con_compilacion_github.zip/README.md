# Gestor de registros móvil

Aplicación Flutter para registrar hasta 50 altas de forma manual, con confirmación de autorización, estados y exportación/compartición CSV.

**Importante:** esta aplicación no crea cuentas de TikTok, no automatiza registros y no se conecta a TikTok. No guardes contraseñas, códigos de verificación ni documentos personales.

## Compilar el APK gratis desde GitHub usando un teléfono

1. Crea una cuenta gratuita en https://github.com/ si todavía no tienes una.
2. Crea un repositorio nuevo, por ejemplo `gestor-registros`.
3. En el repositorio, pulsa **Add file > Upload files** y sube el contenido de este ZIP (descomprime el ZIP primero si GitHub no acepta el archivo).
4. Confirma la carga con **Commit changes** en la rama `main`.
5. Abre la pestaña **Actions**. Si aparece una solicitud para habilitar workflows, acéptala.
6. El flujo **Compilar APK Android** se ejecutará al subir los archivos. También puedes abrirlo y pulsar **Run workflow**.
7. Cuando termine con marca verde, entra en la ejecución y busca **Artifacts**. Descarga `gestor-registros-apk`.
8. Descomprime el archivo descargado y encontrarás `app-release.apk`. Ábrelo en tu Android para instalarlo. Android puede pedirte que permitas instalar esa aplicación desde el navegador o gestor de archivos.

## Si quieres probarlo en una computadora
Con Flutter instalado: `flutter pub get` y `flutter run`.

## Nota sobre costos
GitHub ofrece un nivel gratuito. Los flujos estándar de Actions en repositorios públicos son gratuitos; en repositorios privados se aplica la cuota de uso incluida en el plan y pueden existir cargos si se supera. Revisa la página oficial de facturación antes de habilitar gastos: https://docs.github.com/en/billing/concepts/product-billing/github-actions. Para este proyecto, puedes mantener el repositorio público y no elegir máquinas de compilación especiales para evitar cargos de Actions.
