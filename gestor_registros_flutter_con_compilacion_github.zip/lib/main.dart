import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const RegistryApp());

class RegistryApp extends StatelessWidget {
  const RegistryApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Gestor de registros',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C83FD), brightness: Brightness.dark), useMaterial3: true),
    home: const RegistryHome(),
  );
}

class RegistryHome extends StatefulWidget {
  const RegistryHome({super.key});
  @override
  State<RegistryHome> createState() => _RegistryHomeState();
}

class _RegistryHomeState extends State<RegistryHome> {
  Database? db;
  List<Map<String, Object?>> records = [];
  final statuses = ['Pendiente', 'En revisión', 'Completado', 'Cancelado'];

  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    final path = p.join(await getDatabasesPath(), 'registry.db');
    db = await openDatabase(path, version: 1, onCreate: (d, _) async {
      await d.execute('CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, owner TEXT, authorized INTEGER, status TEXT)');
    });
    await _load();
  }

  Future<void> _load() async {
    final rows = await db!.query('records', orderBy: 'id DESC');
    if (mounted) setState(() => records = rows);
  }

  Future<void> _add() async {
    final user = TextEditingController(), owner = TextEditingController();
    bool authorized = false;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) => AlertDialog(
      title: const Text('Nuevo registro'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: user, decoration: const InputDecoration(labelText: 'Nombre de usuario')),
        TextField(controller: owner, decoration: const InputDecoration(labelText: 'Propietario')),
        CheckboxListTile(value: authorized, onChanged: (v) => setLocal(() => authorized = v ?? false), title: const Text('Autorización confirmada manualmente'), contentPadding: EdgeInsets.zero),
        const Text('No introduzcas contraseñas, códigos ni documentos personales.', style: TextStyle(fontSize: 12)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar'))],
    )));
    if (ok == true && user.text.trim().isNotEmpty && owner.text.trim().isNotEmpty) {
      if (records.length >= 50) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Límite de 50 registros alcanzado.')));
      } else {
        await db!.insert('records', {'username': user.text.trim(), 'owner': owner.text.trim(), 'authorized': authorized ? 1 : 0, 'status': 'Pendiente'});
        await _load();
      }
    }
    user.dispose(); owner.dispose();
  }

  Future<void> _status(Map<String, Object?> r) async {
    final value = await showModalBottomSheet<String>(context: context, builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: statuses.map((s) => ListTile(title: Text(s), onTap: () => Navigator.pop(ctx, s))).toList())));
    if (value != null) { await db!.update('records', {'status': value}, where: 'id=?', whereArgs: [r['id']]); await _load(); }
  }

  Future<void> _export() async {
    final lines = ['usuario,propietario,autorizado,estado', ...records.map((r) => '"${r['username']}","${r['owner']}",${r['authorized'] == 1 ? 'Sí' : 'No'},"${r['status']}"')];
    await Share.share(lines.join('\n'), subject: 'Exportación de registros CSV');
  }

  @override
  Widget build(BuildContext context) {
    final done = records.where((r) => r['status'] == 'Completado').length;
    return Scaffold(
      appBar: AppBar(title: const Text('Gestor de registros'), actions: [IconButton(onPressed: records.isEmpty ? null : _export, icon: const Icon(Icons.ios_share), tooltip: 'Exportar CSV')]),
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Agregar')),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Panel de control', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(children: [
          _stat('Registros', '${records.length}/50'),
          const SizedBox(width: 10),
          _stat('Completados', '$done'),
          const SizedBox(width: 10),
          _stat('Pendientes', '${records.where((r) => r['status'] == 'Pendiente').length}'),
        ]),
        const SizedBox(height: 18),
        const Text('Registros', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Expanded(child: records.isEmpty ? const Center(child: Text('Todavía no hay registros. Pulsa Agregar para comenzar.')) : ListView.builder(itemCount: records.length, itemBuilder: (ctx, i) {
          final r = records[i];
          return Card(child: ListTile(
            title: Text('${r['username']}'),
            subtitle: Text('${r['owner']} · ${r['authorized'] == 1 ? 'Autorizado' : 'Sin autorización'}\n${r['status']}'),
            isThreeLine: true,
            onTap: () => _status(r),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await db!.delete('records', where: 'id=?', whereArgs: [r['id']]); await _load(); }),
          ));
        })),
        const Text('Herramienta educativa: no crea cuentas ni se conecta a TikTok. Registra únicamente autorizaciones verificadas manualmente.', style: TextStyle(fontSize: 11, color: Colors.white70)),
      ])),
    );
  }

  Widget _stat(String label, String value) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(fontSize: 11))]))));
}
